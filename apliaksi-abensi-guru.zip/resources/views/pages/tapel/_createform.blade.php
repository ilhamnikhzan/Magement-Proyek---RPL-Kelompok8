<div class="form-group row">
  <label for="tahun" class="col-sm-2 col-form-label required">Tahun Pelajaran</label>
  <div class="col-sm-10">
    <input type="text" name="tahun" value="{{ old('tahun') }}" class="form-control @error('tahun') is-invalid @enderror" id="tahun" placeholder="Ketik Tahun Pelajaran" required>
    @error('tahun') <span class="invalid-feedback mt-1">{{ $message }}</span> @enderror
  </div>
</div>
<div class="form-group row">
  <label for="semester" class="col-sm-2 col-form-label required">Semester</label>
  <div class="col-sm-10">
    <select name="semester" id="semester" class="form-control selectTwo @error('semester') is-invalid @enderror" data-minimum-results-for-search="Infinity" data-width="100%" required>
      <option value="" disabled selected hidden>-- Pilih --</option>
      @foreach (['1','2'] as $item)
        <option value="{{ $item }}" {{ old('semester') == $item ? 'selected' : '' }}>{{ $item == '1' ? 'Ganjil' : 'Genap' }}</option>
      @endforeach
    </select>
    @error('semester') <span class="invalid-feedback mt-1">{{ $message }}</span> @enderror
  </div>
</div>

<div class="form-group row">
  <label for="mulai" class="col-sm-2 col-form-label required">Tanggal Mulai</label>
  <div class="col-sm-10">
    <input type="date" name="mulai" value="{{ old('mulai') }}" class="form-control @error('mulai') is-invalid @enderror" id="mulai" placeholder="Ketik Tanggal Mulai" required>
    @error('mulai') <span class="invalid-feedback mt-1">{{ $message }}</span> @enderror
  </div>
</div>
<div class="form-group row">
  <label for="selesai" class="col-sm-2 col-form-label required">Tanggal Selesai</label>
  <div class="col-sm-10">
    <input type="date" name="selesai" value="{{ old('selesai') }}" class="form-control @error('selesai') is-invalid @enderror" id="selesai" placeholder="Ketik Tanggal Selesai" required>
    @error('selesai') <span class="invalid-feedback mt-1">{{ $message }}</span> @enderror
  </div>
</div>
<div class="form-group row">
  <label for="is_aktif" class="col-sm-2 col-form-label required">Status</label>
  <div class="col-sm-10">
    <select name="is_aktif" id="is_aktif" class="form-control selectTwo @error('is_aktif') is-invalid @enderror" data-width="100%" data-minimum-results-for-search="Infinity" required>
      <option value="" disabled selected hidden>-- Pilih --</option>
      @foreach (['1','0'] as $item)
        <option value="{{ $item }}" {{ old('is_aktif') == $item ? 'selected' : '' }}>{{ $item == '1' ? 'AKTIF' : 'NON-AKTIF' }}</option>
      @endforeach
    </select>
    @error('is_aktif') <span class="invalid-feedback mt-1">{{ $message }}</span> @enderror
  </div>
</div>
