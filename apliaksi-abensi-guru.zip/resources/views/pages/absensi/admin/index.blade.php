@extends('layouts.main')

@section('css')
@endsection

@section('content')

{{-- Header --}}
<x-content-header :title="'Data Absensi'" :btnBack="false"></x-content-header>

{{-- Content --}}
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col">
        @if ($tapel->count() < 1)
            <div class="card">
              <div class="card-body">
                <div class="p-3">
                  Tahun Pelajaran belum ada yang diaktifkan! <a href="{{ route('tapel.index') }}">Aktifkan Tahun Pelajaran</a>
                </div>
              </div>
            </div>
        @else
        <div class="card">
          <div class="card-header">
            <div class="callout callout-warning my-1">
              <div class="row">
                  <div class="col">
                      <div class="row">
                        <div class="table-responsive">
                          <table class="table-borderless">
                            <tr>
                              <td class="fw-bold">Tahun Pelajaran</td>
                              <td style="width: 1px" class="px-2">:</td>
                              <td>{{ $tapel->tahun }}</td>
                            </tr>
                            <tr>
                              <td class="fw-bold">Semester</td>
                              <td style="width: 1px" class="px-2">:</td>
                              <td>{{ $tapel->semester() }}</td>
                            </tr>
                            <tr>
                              <td class="fw-bold">Tanggal Efektif</td>
                              <td style="width: 1px" class="px-2">:</td>
                              <td>{{ $tapel->mulai()  }} -  {{ $tapel->selesai() }}</td>
                            </tr>
                          </table>
                        </div>

                      </div>
                  </div>
              </div>
          </div>
          </div>
          <div class="card-body">
            <div class="row">

              @if ($months->count() < 1)
                Data bulan tidak ditemukan!
              @else
                @foreach ($months as $bulan)
                  <div class="col-sm-6 col-md-4">
                    <a href="/absensi/admin/{{ $bulan->ym }}" class="text-decoration-none">
                      <div class="info-box">
                        <span class="info-box-icon bg-primary elevation-1"><i class="fas fa-calendar"></i></span>
                        <div class="info-box-content">
                          <span class="info-box-number">
                            {{ $bulan->name }}
                          </span>
                        </div>
                      </div>
                    </a>
                  </div>
                @endforeach
              @endif

            </div>
          </div>
        </div>
        @endif
      </div>
    </div>
  </div>
</section>

<div class="modal fade text-left" id="modal-delete">
  <div class="modal-dialog">
      <div class="modal-content">
          <div class="modal-header">
              <h5 class="modal-title fw-bold" id="exampleModalLabel">Konfirmasi Hapus Data</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
              </button>
          </div>
          <div class="modal-body">
            Data Absensi:
            <p class="text-primary fw-bold" id="delete-name"></p>
            Apakah anda yakin data tersebut akan dihapus?
          </div>
          <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Batal</button>
            <form action="" method="POST" class="d-inline float-end" id="form-delete">
                @csrf
                @method('DELETE')
                <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
            </form>
          </div>
      </div>
  </div>
</div>

@endsection

@section('js')
<script>
  $('.btn-delete').on('click', function(){
    $('#delete-name').html($(this).data('name'));
    $('#form-delete').attr('action', '/kelas/' + $(this).data('id'));
    $('#modal-delete').modal('show');
  });
</script>
@endsection
