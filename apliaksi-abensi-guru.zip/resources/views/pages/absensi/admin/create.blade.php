@extends('layouts.main')

@section('css')
<style>

</style>
@endsection

@section('content')

@php
    use Carbon\Carbon;
@endphp
{{-- Header --}}
<x-content-header :title="'Kelola Absensi ' . $type" :btnBack="true" :redirect="$redirect"></x-content-header>

{{-- Content --}}
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col">
        @if ($tapel->count() < 1)
            <div class="card">
              <div class="card-body">
                <div class="p-3">
                  Tahun Pelajaran belum ada yang diaktifkan! <a href="{{ route('tapel.index') }}">Aktifkan Tahun Pelajaran</a>
                </div>
              </div>
            </div>
        @else
        <div class="card">
          <div class="card-header">
            <div class="callout callout-warning my-1">
              <div class="row">
                  <div class="col">
                      <div class="row">
                        <div class="table-responsive">
                          <table class="table-borderless">
                            <tr>
                              <td class="fw-bold">Tahun Pelajaran</td>
                              <td style="width: 1px" class="px-2">:</td>
                              <td>{{ $tapel->tahun }}</td>
                            </tr>
                            <tr>
                              <td class="fw-bold">Semester</td>
                              <td style="width: 1px" class="px-2">:</td>
                              <td>{{ $tapel->semester() }}</td>
                            </tr>
                            <tr>
                              <td class="fw-bold">Jenis Absen</td>
                              <td style="width: 1px" class="px-2">:</td>
                              <td class="text-capitalize">Absen {{ $type }}</td>
                            </tr>
                            <tr>
                              <td class="fw-bold">Hari, Tanggal</td>
                              <td style="width: 1px" class="px-2">:</td>
                              <td>{{ Carbon::parse($tanggal)->locale('id_ID')->isoFormat('dddd, D MMMM Y') }}</td>
                            </tr>
                          </table>
                        </div>

                      </div>
                  </div>
              </div>
          </div>
          </div>
          <div class="card-body">
            @if ($gurus->count() < 1)
              <div class="p-3">
                Belum ada data Guru!
              </div>
            @else
              <div class="table-responsive">
                <form action="{{ route('absensi.admin.store', [$type, $tanggal]) }}" method="POST">
                  @csrf
                  <table id="" class="table table-sm table-striped table-hover table-bordered border-dark">
                      <thead>
                          <tr class="bg-dark text-white">
                              <th scope="col" rowspan="2" class="border-dark text-center align-middle bg-info">#</th>
                              <th scope="col" rowspan="2" class="border-dark text-center align-middle bg-info">NIP/NUPTK</th>
                              <th scope="col" rowspan="2" class="border-dark text-center align-middle bg-info">Nama Guru</th>
                              <th scope="col" rowspan="2" class="border-dark text-center align-middle bg-info">L/P</th>
                              <th scope="col" rowspan="2" class="border-dark text-center align-middle bg-info" style="min-width: 100px">Status</th>
                          </tr>
                      </thead>
                      <tbody>
                        @foreach ($gurus as $index => $item)
                          <tr>
                            <td class="border-dark">{{ $loop->iteration }}</td>
                            <td class="border-dark">{{ $item->nip }}/{{ $item->nuptk }}</td>
                            <td class="border-dark text-uppercase">
                              <input type="hidden" name="guru_id[]" value="{{ $item->id }}">
                              {{ $item->user->name }}
                            </td>
                            <td class="border-dark text-uppercase text-center">
                              {{ $item->user->jk == 'laki-laki' ? 'L' : 'P' }}
                            </td>
                            <td class="border-dark">
                              <select name="status[]" id="" class="form-control form-select">
                                <option value=""></option>
                                <option value="h" {{ optional($absen->where('guru_id', $item->id)->where('tanggal', $tanggal)->first())->status == 'h' ? 'selected' : '' }}>Hadir</option>
                                <option value="s" {{ optional($absen->where('guru_id', $item->id)->where('tanggal', $tanggal)->first())->status == 's' ? 'selected' : '' }}>Sakit</option>
                                <option value="i" {{ optional($absen->where('guru_id', $item->id)->where('tanggal', $tanggal)->first())->status == 'i' ? 'selected' : '' }}>Izin</option>
                                <option value="a" {{ optional($absen->where('guru_id', $item->id)->where('tanggal', $tanggal)->first())->status == 'a' ? 'selected' : '' }}>Alpa</option>
                              </select>
                            </td>
                          </tr>
                        @endforeach
                      </tbody>
                  </table>
                  <button type="submit" class="btn btn-success float-right">
                    Simpan
                </button>
                <div class="checkbox float-right me-3">
                    <label>
                        <input type="checkbox" class="mt-3" required>
                        Saya yakin akan mengubah data tersebut
                    </label>
                </div>
                </form>
              </div>
            @endif
          </div>
        </div>
        @endif
      </div>
    </div>
  </div>
</section>

<div class="modal fade text-left" id="modal-delete">
  <div class="modal-dialog">
      <div class="modal-content">
          <div class="modal-header">
              <h5 class="modal-title fw-bold" id="exampleModalLabel">Konfirmasi Hapus Data</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
              </button>
          </div>
          <div class="modal-body">
            Data Absensi:
            <p class="text-primary fw-bold" id="delete-name"></p>
            Apakah anda yakin data tersebut akan dihapus?
          </div>
          <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Batal</button>
            <form action="" method="POST" class="d-inline float-end" id="form-delete">
                @csrf
                @method('DELETE')
                <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
            </form>
          </div>
      </div>
  </div>
</div>

@endsection

@section('js')
<script>

</script>
@endsection
