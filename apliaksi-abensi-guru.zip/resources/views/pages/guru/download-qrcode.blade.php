<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>QR CODE - {{ $guru->user->name }}</title>
</head>
<body>

<div class="" style="text-align: center; margin-top: 80px">

  <div style="margin-bottom: 20px">
    <h2>NAMA: {{ $guru->user->name }}</h2> <h2>NIP/NUPTK: {{ $guru->nip }}/{{ $guru->nuptk }}</h2>
  </div>

  {!! QrCode::size(500)->generate($guru->barcode->idt) !!}
</div>

<script>
  window.onload = function() {
    window.print();
  }
</script>

</body>
</html>
