@extends('layouts.main')

@section('css')
@endsection

@section('content')

{{-- Header --}}
<x-content-header :title="'Rekapitulasi Absensi'" :btnBack="false"></x-content-header>

{{-- Content --}}
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col">
        @if ($tapel->count() < 1)
            <div class="card">
              <div class="card-body">
                <div class="p-3">
                  Tahun Pelajaran belum ada yang diaktifkan!
                  @can('admin')
                    <a href="{{ route('tapel.index') }}">Aktifkan Tahun Pelajaran</a>
                  @endcan
                </div>
              </div>
            </div>
        @else
        <div class="card">
          <div class="card-header">
            <div class="callout callout-warning my-1">
              <div class="row">
                  <div class="col">
                      <div class="row">
                        <div class="table-responsive">
                          <table class="table-borderless">
                            <tr>
                              <td class="fw-bold">Tahun Pelajaran</td>
                              <td style="width: 1px" class="px-2">:</td>
                              <td>{{ $tapel->tahun }}</td>
                            </tr>
                            <tr>
                              <td class="fw-bold">Semester</td>
                              <td style="width: 1px" class="px-2">:</td>
                              <td>{{ $tapel->semester() }}</td>
                            </tr>
                            <tr>
                              <td class="fw-bold">Tanggal Efektif</td>
                              <td style="width: 1px" class="px-2">:</td>
                              <td>{{ $tapel->mulai()  }} -  {{ $tapel->selesai() }}</td>
                            </tr>
                          </table>
                        </div>

                      </div>
                  </div>
              </div>
          </div>
          </div>
          <div class="card-body">
            <form action="{{ route('rekapitulasi.print') }}" method="GET" target="_blank">
              <div class="row">

                <div class="col-md-6">
                  <div class="form-group">
                    <label for="jenis" class="required">Jenis Rekapitulasi</label>
                    <select name="jenis" id="jenis" class="form-control @error('jenis') is-invalid @enderror" data-width="100%" required>
                      <option value="" disabled selected hidden>-- Pilih --</option>
                      <option value="perbulan" {{ old('jenis') == 'perbulan' ? 'selected' : '' }}>Per-Bulan</option>
                      <option value="persemester" {{ old('jenis') == 'persemester' ? 'selected' : '' }}>Per-Semester</option>
                    </select>
                    @error('jenis') <span class="invalid-feedback mt-1">{{ $message }}</span> @enderror
                  </div>
                </div>

                <div class="col-md-6 d-none" id="yearmonth-col">
                  <div class="form-group">
                    <label for="yearmonth" class="required">Bulan</label>
                    <select name="yearmonth" id="yearmonth" class="form-control @error('yearmonth') is-invalid @enderror" data-width="100%">
                      <option value="" disabled selected hidden>-- Pilih --</option>
                      @foreach ($months as $item)
                        <option value="{{ $item->ym }}" {{ old('yearmonth') == $item->ym ? 'selected' : '' }}>{{ $item->name }}</option>
                      @endforeach
                    </select>
                    @error('yearmonth') <span class="invalid-feedback mt-1">{{ $message }}</span> @enderror
                  </div>
                </div>

              </div>
              <div class="row">
                <div class="col-md-6">
                  <button type="submit" class="btn btn-primary btn-sm">
                    <i class="fa fa-download"></i>
                    Download Rekapitulasi
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
        @endif
      </div>
    </div>
  </div>
</section>

@endsection

@section('js')
<script>
  $(document).ready(function(){
    $('#jenis').on('change', function(){
      ymToggle();
    });

    function ymToggle(){
      var jenis = $('#jenis').val();
      if (jenis == 'perbulan') {
        $('#yearmonth').attr('required', 'required');
        $('#yearmonth-col').removeClass('d-none');
      } else{
        $('#yearmonth').removeAttr('required');
        $('#yearmonth').val('');
        $('#yearmonth-col').addClass('d-none');
      }

    }
  });
</script>
@endsection
