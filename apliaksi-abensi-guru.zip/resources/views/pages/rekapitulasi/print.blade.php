<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>
    @if ($jenis == 'perbulan')
    REKAPITULASI ABSENSI {{ $sekolah->name }} - {{ $namabulan }}
    @else
      REKAPITULASI ABSENSI {{ $sekolah->name }} - Tahun {{ $tapel->tahun }} Semester {{ $tapel->semester() }}
    @endif
  </title>
  <style>
    .fw-bold{
      font-weight: bold;
    }
    .align-middle{
      align-content: center;
    }
    .text-center{
      text-align: center;
    }
  </style>
</head>
<body style="font-family: 'Times New Roman'; font-size: 14px">

  <div class="row" style="padding: 30px">
    <div class="text-center" style="text-align: center">
      <h3 class="fw-bold mb-1" style="margin-top: 0px; margin-bottom: 0px;">REKAPITULASI ABSENSI</h3>
      <h3 class="fw-bold" style="margin-top: 0px; margin-bottom: 0px;">{{ $sekolah->name }}</h3>
      <p style="margin-top: 0px; margin-bottom: 0px;">{{ $sekolah->alamat }}</p>
      <br>
      <hr />
    </div>

    <div class="col-12">
      <div class="hero bg-primary text-white">
        <div class="">
          <table class="table-sm" border="0" cellspacing="1">
            <tr>
              <td class="fw-bold">Tahun Pelajaran</td>
              <td>:</td>
              <td>{{ $tapel->tahun }}</td>
            </tr>
            <tr>
              <td class="fw-bold">Semester</td>
              <td>:</td>
              <td>{{ $tapel->semester() }}</td>
            </tr>
            <tr>
              <td class="fw-bold">Jenis Rekapitulasi</td>
              <td>:</td>
              <td>{{ $jenis }}</td>
            </tr>
            @if ($jenis == 'perbulan')
              <tr>
                <td class="fw-bold">Bulan</td>
                <td>:</td>
                <td>{{ $namabulan }}</td>
              </tr>
            @else
              <tr>
                <td class="fw-bold">Tanggal</td>
                <td>:</td>
                <td>{{ $tapel->mulai()  }} -  {{ $tapel->selesai() }}</td>
              </tr>
            @endif

          </table>
        </div>
      </div>
      <hr />
    </div>

    <div class="section-body" style="margin-top: 30px">
      <div class="card">
        <div class="card-body invoice-print">
          <div class="table-responsive">
            <table class="table table-sm table-striped table-bordered" border="1" cellspacing="0"  style="width: 100%">
              <thead class="">
                <tr class=" text-white">
                  <td rowspan="3" class="align-middle text-center fw-bold ">#</td>
                  <td rowspan="3" class="align-middle text-center fw-bold ">NIP/NUPTK</td>
                  <td rowspan="4" class="align-middle text-center fw-bold ">Nama Guru</td>
                  <td rowspan="3" class="align-middle text-center fw-bold ">L/P</td>
                  <td colspan="8" class="align-middle text-center fw-bold ">Jumlah</td>
                </tr>
                <tr class=" text-white">
                  <td class="bg-success  align-middle text-center fw-bold" style="min-width: 30px" colspan="4">Masuk</td>
                  <td class="bg-primary  align-middle text-center fw-bold" style="min-width: 30px" colspan="4">Pulang</td>
                </tr>
                <tr class=" text-white">
                  @for ($i = 0; $i < 2; $i++)
                    <td class="bg-success  align-middle text-center fw-bold" style="min-width: 30px">H</td>
                    <td class="bg-primary  align-middle text-center fw-bold" style="min-width: 30px">S</td>
                    <td class="bg-warning  align-middle text-center fw-bold" style="min-width: 30px">I</td>
                    <td class="bg-danger  align-middle text-center fw-bold" style="min-width: 30px">A</td>
                  @endfor
                </tr>
              </thead>
              <tbody>
                @foreach ($gurus as $i => $item)

                  <tr class="">
                    <td class="">{{ $loop->iteration }}</td>
                    <td class="">{{ $item->nip }} / {{ $item->nuptk }}</td>
                    <td class="">{{ $item->user->name }}</td>
                    <td class="align-center text-center">{{ $item->user->jk == 'laki-laki' ? 'L' : 'P' }}</td>

                    {{-- ABSEN MASUK --}}
                    @php
                      $H = $absens->where('guru_id', $item->id)
                                    ->where('type', 'masuk')
                                    ->where('status', 'h')
                                    ->count();
                      $S = $absens->where('guru_id', $item->id)
                                    ->where('type', 'masuk')
                                    ->where('status', 's')
                                    ->count();
                      $I = $absens->where('guru_id', $item->id)
                                    ->where('type', 'masuk')
                                    ->where('status', 'i')
                                    ->count();
                      $A = $absens->where('guru_id', $item->id)
                                    ->where('type', 'masuk')
                                    ->where('status', 'a')
                                    ->count();
                    @endphp

                    <td class="align-middle text-center "> {{ $H > 0 ? $H : ''}} </td>
                    <td class="align-middle text-center "> {{ $S > 0 ? $S : '' }} </td>
                    <td class="align-middle text-center "> {{ $I > 0 ? $I : '' }} </td>
                    <td class="align-middle text-center "> {{ $A > 0 ? $A : '' }} </td>

                    @php
                      $H = $absens->where('guru_id', $item->id)
                                    ->where('type', 'pulang')
                                    ->where('status', 'h')
                                    ->count();
                      $S = $absens->where('guru_id', $item->id)
                                    ->where('type', 'pulang')
                                    ->where('status', 's')
                                    ->count();
                      $I = $absens->where('guru_id', $item->id)
                                    ->where('type', 'pulang')
                                    ->where('status', 'i')
                                    ->count();
                      $A = $absens->where('guru_id', $item->id)
                                    ->where('type', 'pulang')
                                    ->where('status', 'a')
                                    ->count();
                    @endphp

                    <td class="align-middle text-center "> {{ $H > 0 ? $H : ''}} </td>
                    <td class="align-middle text-center "> {{ $S > 0 ? $S : '' }} </td>
                    <td class="align-middle text-center "> {{ $I > 0 ? $I : '' }} </td>
                    <td class="align-middle text-center "> {{ $A > 0 ? $A : '' }} </td>

                  </tr>
                @endforeach
              </tbody>
            </table>
          </div>
        </div>
      </div>

    </div>

    <script>
      window.onload = function() {
        var style = document.createElement('style');
        style.innerHTML = '@media print { @page { size: landscape; } }';
        document.head.appendChild(style);
        window.print();
      }
    </script>
</body>
</html>
