<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;

use App\Helpers\DummyHelper;
use App\Models\Absen;
use App\Models\Admin;
use App\Models\Barcode;
use App\Models\Guru;
use App\Models\Kepsek;
use App\Models\Libur;
use App\Models\Sekolah;
use App\Models\Tapel;
use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {

        // TAPEL
        collect([
          [
            'tahun' => '2024/2025',
            'semester' => '1',
            'mulai' => '2024-07-15',
            'selesai' => '2024-12-23',
            'is_aktif' => 1,
          ],
          // [
          //   'tahun' => '2024/2025',
          //   'semester' => '2',
          //   'mulai' => '2025-01-06',
          //   'selesai' => '2025-06-21',
          //   'is_aktif' => 0,
          // ],
        ])->each(fn($q) => Tapel::create($q));

        // LIBUR
        // collect([
        //   [
        //     'tanggal' => '2024-07-25',
        //     'keterangan' => 'Rapat MGMP',
        //   ],
        // ])->each(fn($q) => Libur::create($q));

        // SEKOLAH
        collect([
          [
            'name' => 'SDN 1 INDONESIA',
            'telepon' => DummyHelper::randTelepon(),
            'email' => 'info@sdn1.com',
            'alamat' => DummyHelper::randAlamat(),
            'logo' => 'logosekolah.png',
          ],
        ])->each(fn($q) => Sekolah::create($q));

        // USER
        collect([
          [
            'name' => 'Nama Admin',
            'jk' => 'laki-laki',
            'role' => 'admin',
            'telepon' => DummyHelper::randTelepon(),
            'alamat' => DummyHelper::randAlamat(),
            'username' => 'admin',
            'password' => 'password',
            'idt' => DummyHelper::idt(),
          ],
          // [
          //   'name' => 'Nama Kepsek',
          //   'jk' => 'laki-laki',
          //   'role' => 'kepsek',
          //   'telepon' => DummyHelper::randTelepon(),
          //   'alamat' => DummyHelper::randAlamat(),
          //   'username' => 'kepsek',
          //   'password' => 'password',
          //   'idt' => DummyHelper::idt(),
          // ],
          // [
          //   'name' => 'Nama Guru',
          //   'jk' => 'laki-laki',
          //   'role' => 'guru',
          //   'telepon' => DummyHelper::randTelepon(),
          //   'alamat' => DummyHelper::randAlamat(),
          //   'username' => 'guru',
          //   'password' => 'password',
          //   'idt' => DummyHelper::idt(),
          // ],
        ])->each(fn($q) => User::create($q));

        Admin::create([
          'user_id' => 1
        ]);

//         Kepsek::create([
//           'user_id' => 2,
//           'nip' => DummyHelper::randNip(),
//           'nuptk' => DummyHelper::randNuptk(),
//         ]);
//
//         Guru::create([
//           'user_id' => 3,
//           'nip' => '',
//           'nuptk' => DummyHelper::randNuptk(),
//         ]);
//
//         Barcode::create([
//           'guru_id' => 1,
//           'idt' => DummyHelper::idt()
//         ]);

        // \App\Models\Admin::factory(50)->create();
        // \App\Models\Barcode::factory(10)->create();
        // \App\Models\Kepsek::factory(10)->create();

        // collect([
        //   [
        //     'guru_id' => 1,
        //     'tapel_id' => 1,
        //     'status' => 'h',
        //     'type' => 'masuk',
        //     'tanggal' => '2024-07-15',
        //   ],
        //   [
        //     'guru_id' => 2,
        //     'tapel_id' => 1,
        //     'status' => 'i',
        //     'type' => 'masuk',
        //     'tanggal' => '2024-07-07',
        //   ],
        //   [
        //     'guru_id' => 1,
        //     'tapel_id' => 1,
        //     'status' => 'h',
        //     'type' => 'pulang',
        //     'tanggal' => '2024-07-15',
        //   ],
        //   [
        //     'guru_id' => 1,
        //     'tapel_id' => 2,
        //     'status' => 'h',
        //     'type' => 'masuk',
        //     'tanggal' => '2024-08-02',
        //   ],
        // ])->each(fn($q) => Absen::create($q));

    }
}
