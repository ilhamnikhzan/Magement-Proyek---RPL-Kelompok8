<?php

use Illuminate\Support\Facades\Broadcast;

/*
|--------------------------------------------------------------------------
| Saluran Siaran (Broadcast Channels)
|--------------------------------------------------------------------------
|
| Di sini kamu dapat mendaftarkan semua saluran siaran (broadcasting channels)
| yang didukung oleh aplikasimu. Callback otorisasi saluran yang diberikan
| digunakan untuk memeriksa apakah pengguna yang terautentikasi boleh
| mendengarkan saluran tersebut.
|
*/

Broadcast::channel('App.Models.User.{id}', function ($user, $id) {
    return (int) $user->id === (int) $id;
});
