<?php

namespace App\Http\Controllers;

use App\Helpers\DummyHelper;
use App\Models\Kepsek;
use App\Models\User;
use Illuminate\Http\Request;

class KepsekController extends Controller
{
  /**
   * Display a listing of the resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function index(Request $request)
  {
      $kepsek = Kepsek::query();
      return view('pages.kepsek.index',[
        'kepsek' => $kepsek->with('user')->get(),
      ]);
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function create()
  {
      return view('pages.kepsek.create');
  }

  /**
   * Store a newly created resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
  public function store(Request $request)
  {
      $request->validate([
        'name' => 'required',
        'jk' => 'required',
        'telepon' => 'nullable',
        'alamat' => 'nullable',
        'nip' => 'nullable|unique:kepseks,nip',
        'nuptk' => 'nullable|unique:kepseks,nuptk',
        'username' => 'required|unique:users,username',
        'password' => 'required',
      ]);

      $request['idt'] = DummyHelper::idt();
      $request['role'] = 'kepsek';
      $user = User::create($request->except('nip','nuptk'));

      $request['user_id'] = $user->id;
      Kepsek::create($request->only('user_id','nip','nuptk'));

      return redirect(route('kepsek.index'))->withSuccess('Data berhasil ditambahkan!');
  }

  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function show(Kepsek $kepsek)
  {
    $kepsek->load('user');
    return view('pages.kepsek.show', compact('kepsek'));
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function edit(Kepsek $kepsek)
  {
      $kepsek->load('user');
      return view('pages.kepsek.edit', compact('kepsek'));
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function update(Request $request, Kepsek $kepsek)
  {
      $request->validate([
        'name' => 'required',
        'jk' => 'required',
        'telepon' => 'nullable',
        'alamat' => 'nullable',
        'nip' => 'nullable|unique:kepseks,nip,' . $kepsek->id,
        'nuptk' => 'nullable|unique:kepseks,nuptk,' . $kepsek->id,
        'username' => 'required|unique:users,username,' . $kepsek->user_id,
        'password' => 'nullable',
      ]);

      $kepsek->update($request->only('nip','nuptk'));
      filled($request->password) ? $kepsek->user->update($request->except('nip','nuptk'))
                                 : $kepsek->user->update($request->except('password','nip','nuptk'));

      return redirect(route('kepsek.index'))->withSuccess('Data berhasil diperbarui!');
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function destroy(Kepsek $kepsek)
  {
      $kepsek->user->delete();
      return redirect(route('kepsek.index'))->withSuccess('Data berhasil dihapus!');
  }
}
