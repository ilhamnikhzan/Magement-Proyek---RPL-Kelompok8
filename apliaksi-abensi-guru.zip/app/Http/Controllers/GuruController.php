<?php

namespace App\Http\Controllers;

use App\Helpers\DummyHelper;
use App\Models\Barcode;
use App\Models\Guru;
use App\Models\User;
use Illuminate\Http\Request;

class GuruController extends Controller
{
  /**
   * Display a listing of the resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function index(Request $request)
  {
      $this->authorize('admin');
      $guru = Guru::query();
      return view('pages.guru.index',[
        'guru' => $guru->with('user')->get(),
      ]);
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function create()
  {
      $this->authorize('admin');
      return view('pages.guru.create');
  }

  /**
   * Store a newly created resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
  public function store(Request $request)
  {
      $request->validate([
        'name' => 'required',
        'jk' => 'required',
        'telepon' => 'nullable',
        'alamat' => 'nullable',
        'nip' => 'nullable|unique:gurus,nip',
        'nuptk' => 'nullable|unique:gurus,nuptk',
        'username' => 'required|unique:users,username',
        'password' => 'required',
      ]);

      $request['idt'] = DummyHelper::idt();
      $request['role'] = 'guru';
      $user = User::create($request->except('nip','nuptk'));

      $request['user_id'] = $user->id;
      $guru = Guru::create($request->only('user_id','nip','nuptk'));

      $request['guru_id'] = $guru->id;
      Barcode::create($request->only('guru_id','idt'));

      return redirect(route('guru.index'))->withSuccess('Data berhasil ditambahkan!');
  }

  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function show(Request $request, Guru $guru)
  {
    $guru->load(['user','barcode']);
    if ($request->download == 'qrcode') {
      return view('pages.guru.download-qrcode', compact('guru'));
    } else {
      return view('pages.guru.show', compact('guru'));
    }
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function edit(Guru $guru)
  {
      $this->authorize('admin');
      $guru->load('user');
      return view('pages.guru.edit', compact('guru'));
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function update(Request $request, Guru $guru)
  {
      $request->validate([
        'name' => 'required',
        'jk' => 'required',
        'telepon' => 'nullable',
        'alamat' => 'nullable',
        'nip' => 'nullable|unique:gurus,nip,' . $guru->id,
        'nuptk' => 'nullable|unique:gurus,nuptk,' . $guru->id,
        'username' => 'required|unique:users,username,' . $guru->user_id,
        'password' => 'nullable',
      ]);

      $guru->update($request->only('nip','nuptk'));
      filled($request->password) ? $guru->user->update($request->except('nip','nuptk'))
                                 : $guru->user->update($request->except('password','nip','nuptk'));

      return redirect(route('guru.index'))->withSuccess('Data berhasil diperbarui!');
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function destroy(Guru $guru)
  {
      $guru->user->delete();
      return redirect(route('guru.index'))->withSuccess('Data berhasil dihapus!');
  }
}
