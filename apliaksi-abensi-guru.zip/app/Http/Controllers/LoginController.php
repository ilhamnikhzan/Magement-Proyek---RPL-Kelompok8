<?php

namespace App\Http\Controllers;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class LoginController extends Controller
{
    public function index() : View {
      return view('pages.auth.login');
    }

    public function cekLogin(Request $request) : RedirectResponse {
      $input = $request->validate([
        'username' => ['required'],
        'password' => ['required'],
      ]);

      if (Auth::attempt($input)) {
          return redirect(route('dashboard.index'))->withInfo('Anda berhasil masuk!');
      } else {
        return back()->withFailed('Username atau password salah!');
      }
    }
}
