<?php

namespace App\Http\Controllers;

use App\Models\Admin;
use App\Models\Guru;
use App\Models\Kelas;
use App\Models\Kepsek;
use App\Models\Libur;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    public function index(){
      $data = [];

      $user = Auth::user();
      if ($user->isAdmin()) $data = array_merge($data, $this->dataAdmin());
      if ($user->isGuru()) $data = array_merge($data, $this->dataGuru());
      if ($user->isKepsek()) $data = array_merge($data, $this->dataKepsek());
      return view('pages.dashboard.index', compact('data'));
    }

    private function dataAdmin(){
      return [
        [
          'title' => 'Data Guru',
          'count' => Guru::count(),
          'colour' => 'bg-primary',
          'route' => 'guru.index',
        ],
        [
          'title' => 'Data Admin',
          'count' => Admin::count(),
          'colour' => 'bg-success',
          'route' => 'admin.index',
        ],
        [
          'title' => 'Data Kepsek',
          'count' => Kepsek::count(),
          'colour' => 'bg-warning',
          'route' => 'kepsek.index',
        ],
        [
          'title' => 'Data Hari Libur',
          'count' => Libur::count(),
          'colour' => 'bg-danger',
          'route' => 'libur.index',
        ],
      ];
    }

    private function dataKepsek(){
      return [
        [
          'title' => 'Rekapitulasi Absensi',
          'count' => '',
          'colour' => 'bg-primary',
          'route' => 'rekapitulasi.index',
        ],
      ];
    }

    private function dataGuru(){
      return [
        [
          'title' => 'Absen Hari Ini',
          'count' => '',
          'colour' => 'bg-success',
          'route' => 'absensi.guru.index',
        ],
      ];
    }
}
