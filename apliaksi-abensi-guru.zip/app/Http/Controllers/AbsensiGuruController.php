<?php

namespace App\Http\Controllers;

use App\Models\Absen;
use App\Models\Barcode;
use App\Models\Guru;
use App\Models\Libur;
use App\Models\Tapel;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class AbsensiGuruController extends Controller
{
  public function index() {
    $tapel = Tapel::where('is_aktif', 1)->exists() ? Tapel::where('is_aktif', 1)->first() : abort(404);
    $tanggal = date('Y-m-d');
    $libur = Libur::pluck('tanggal');

    if ($libur->contains($tanggal)) {
      $is_libur = true;
    } else if (Str::before(Carbon::parse($tanggal)->locale('id_ID')->isoFormat('dddd, D MMMM Y'), ',') == 'Minggu') {
      $is_libur = true;
    } else {
      $is_libur = false;
    }

    $absen = Absen::where('guru_id', auth()->user()->guru->id)
                  ->where('tanggal', $tanggal)
                  ->where('tapel_id', $tapel->id)
                  ->get();

    return view('pages.absensi.guru.index',[
      'tapel' => $tapel,
      'tanggal' => date('Y-m-d'),
      'is_libur' => $is_libur,
      'absen' => $absen
    ]);

  }
  public function create($type) {
    if (($type != 'masuk') && ($type != 'pulang')) {
      abort(404);
    }
    $tapel = Tapel::where('is_aktif', 1)->firstOrFail();
    return view('pages.absensi.guru.create',[
      'tapel' => $tapel,
      'tanggal' => date('Y-m-d'),
      'type' => $type
    ]);
  }

  public function store(Request $request, $tanggal, $type) {

    $tapel = Tapel::where('is_aktif', 1)->firstOrFail();

    $guruId = Barcode::where('idt', $request->idt)->first()->guru_id ?? null;
    $guru = Guru::whereId($guruId)->with('user')->get();

    if ($guruId != null) {
      $absen = Absen::where('guru_id', $guruId)
                    ->where('tanggal', $tanggal)
                    ->where('type', $type)->count() >= 1;
      if ($absen) {
        return redirect(route('absensi.guru.index'))->withWarning('Anda sudah melakukan absen ' . $type . ' pada hari ini!');
      } else {
        try {
          DB::beginTransaction();
            Absen::create([
              'guru_id' => $guruId,
              'tapel_id' => $tapel->id,
              'type' => $type,
              'tanggal' => $tanggal,
              'status' => 'h'
            ]);
          DB::commit();
          return redirect(route('absensi.guru.index'))->withSuccess('Anda berhasil melakukan absen ' . $type . '!');
        } catch (\Throwable $th) {
          DB::rollBack();
          return back()->withFailed('Gagal! silakan coba lagi!');
        }
      }

    } else {
      return redirect(route('absensi.guru.index'))->withFailed('Data tidak ditemukan!');
    }

  }
}
